package beans;



public class Test  implements Runnable  {

	 int i = 1;
	
	@Override
	public void run() {
		System.out.println("running"+ i++);
		
	}
	 public void name() 
	 {
		
	}
		  
	
	
			  
		  
	
	 
	  
	public static void main(String[] args) 
	{
	    Thread t = new Thread(new Test());
	    Thread t1 = new Thread(new Test());
	           t.run();
	           t.run();
	           t1.start();;
	           t.start();
	          
	}








	
	
}
	
	

	/*abstract class B extends A
	{
		public void printA()
		{
			System.out.println("class B");
		}
	}
	
	abstract class A 
	{
		public void printB()
		{
			System.out.println("class A");
		}
	} */



