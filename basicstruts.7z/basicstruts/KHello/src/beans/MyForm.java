package beans;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;


public class MyForm extends ActionForm{
	String name;
	public void setName(String name)
	{
		this.name=name;
	}
	public String getName() 
	{
		return name;
	}
}
